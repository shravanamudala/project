package routes

import (
	"encoding/json"
	"net/http"

	"github.com/shravan/workday/models"
)

type userHandler struct {
	userService UserService
}

func (uh *userHandler) SaveUser(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(models.User{})
}

func (uh *userHandler) UpdateUser(w http.ResponseWriter, r *http.Request) {

}
func (uh *userHandler) GetUser(w http.ResponseWriter, r *http.Request) {
	return
}
func (uh *userHandler) DeleteUser(w http.ResponseWriter, r *http.Request) {
	return
}
func (uh *userHandler) GetUsers(w http.ResponseWriter, r *http.Request) {
	return
}

func NewUserHandler(userService UserService) *userHandler {
	return &userHandler{userService: userService}
}
