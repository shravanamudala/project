package routes

import (
	"net/http"

	"github.com/shravan/workday/models"
)

type UserHandler interface {
	GetUsers(w http.ResponseWriter, r *http.Request)
	GetUser(w http.ResponseWriter, r *http.Request)
	SaveUser(w http.ResponseWriter, r *http.Request)
	UpdateUser(w http.ResponseWriter, r *http.Request)
	DeleteUser(w http.ResponseWriter, r *http.Request)
}

type UserService interface {
	GetUsers() ([]models.User, error)
	GetUser(id int) (models.User, error)
	SaveUser(user models.UserRequest) (models.User, error)
	UpdateUser(id int, user models.UserRequest) (models.User, error)
	DeleteUser(id int) (models.User, error)
}
