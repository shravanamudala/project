package repository

type UserRepository interface {
	Get
}
